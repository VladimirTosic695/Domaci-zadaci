package vladimir.tosic;

public class Tacka {
	
	double x, y;
	
	Tacka(){
		
	}
	Tacka(double x, double y){
		this.x = x;
		this.y = y;
	}
	
	public void setX (double x) {
		this.x = x;
	}
	public void setY (double y) {
		this.y = y;
	}
	public double getX () {
		return x;
	}
	public double getY () {
		return y;
	}
	
	public double rastojanje(Tacka t) {
		return Math.sqrt(Math.pow(x - t.x, 2) + Math.pow(y - t.y, 2));
	}
	
	public String ispisivanje(Tacka t) {
		return "Rastojanje izmedju dve tacke: " + rastojanje(t);
	}
	

}
