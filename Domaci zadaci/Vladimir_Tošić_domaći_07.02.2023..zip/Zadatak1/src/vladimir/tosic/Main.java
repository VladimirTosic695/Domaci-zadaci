package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Tacka t1 = new Tacka(2,2);
		Tacka t2 = new Tacka(5,0);
		
		System.out.println("Koordinate tacke 1: (" + t1.getX() + "," + t1.getY() + ")");
		System.out.println("Koordinate tacke 2: (" + t2.getX() + "," + t2.getY() + ")");
		System.out.println(t1.ispisivanje(t2));
		
		System.out.println("Unesite x za prvu tacku.");
		t1.setX(sc.nextDouble());
		System.out.println("Unesite y za prvu tacku.");
		t1.setY(sc.nextDouble());
		System.out.println("Unesite x za drugu tacku.");
		t2.setX(sc.nextDouble());
		System.out.println("Unesite y za drugu tacku.");
		t2.setY(sc.nextDouble());
		
		System.out.println("Koordinate tacke 1: (" + t1.getX() + "," + t1.getY() + ")");
		System.out.println("Koordinate tacke 2: (" + t2.getX() + "," + t2.getY() + ")");
		System.out.println(t1.ispisivanje(t2));
		
		sc.close();
		
	}

}
