package vladimir.tosic;

public class Sfera extends Predmet {
	
	double r;
	
	Sfera(){
		
	}
	Sfera(char oznaka, double m, double g, double r){
		super(oznaka, m, g);
		this.r = r;
	}
	public double zapremina() {
		return 4.0/3 * Math.pow(r, 3) * Math.PI;
	}

	public double specificnaTezina() {
		return masa * g / zapremina();
	}
	public String ispisSfere() {
		return super.ispisPredmet() + "(sfera)"+ "\nZapremina sfere: " + zapremina()
		+ "\nSpecificna tezina sfere: " + specificnaTezina();
	}
	

}
