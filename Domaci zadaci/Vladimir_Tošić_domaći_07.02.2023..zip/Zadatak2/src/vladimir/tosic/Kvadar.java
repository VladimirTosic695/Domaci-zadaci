package vladimir.tosic;

public class Kvadar extends Predmet {
	
	double a, b, h;
	
	Kvadar(){
		a = 1;
		b = 1; 
		h = 1;
	}
	Kvadar(char oznaka, double masa, double g,double a, double b, double h){
		super(oznaka, masa, g);
		this.a = a;
		this.b = b;
		this.h = h;
	}
	public double zapremina() {
		return a * b * h;
	}
	public double specificnaTezina () {
		return masa * g / zapremina();
	}
	
	public String ispisKvadra() {
		return super.ispisPredmet() + "(kvadar)" + "\nZapremina kvadra: " + zapremina()
		+ "\nSpecificna tezina kvadra: " + specificnaTezina();
	}
	

}
