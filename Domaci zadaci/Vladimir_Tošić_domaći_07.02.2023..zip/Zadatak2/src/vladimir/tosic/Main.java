package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		
		Kvadar k = new Kvadar('k', 15, 9.81, 2, 5, 6);
		
		System.out.println(k.ispisKvadra());
		
		Sfera s = new Sfera('s', 15, 9.81, 9);
		
		System.out.println(s.ispisSfere());

	}

}
