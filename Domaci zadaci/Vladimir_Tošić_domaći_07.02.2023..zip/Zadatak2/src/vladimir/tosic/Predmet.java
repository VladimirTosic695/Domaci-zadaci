package vladimir.tosic;

public abstract class Predmet {
	
	char oznaka;
	double masa,g;
	
	Predmet(){}
	
	Predmet(char oznaka, double masa, double g){
		this.oznaka = oznaka;
		this.masa = masa;
		this.g = g;
	}
	
	public char getOznaka() {
		return oznaka;
	}
	public abstract double zapremina();
	
	public abstract double specificnaTezina ();
	
	public String ispisPredmet() {
		return "Predmet mase: " + masa + "\nGravitaciono ubrzanje: " + g + 
				"\nOznaka predmeta: " + oznaka;
	}
}
