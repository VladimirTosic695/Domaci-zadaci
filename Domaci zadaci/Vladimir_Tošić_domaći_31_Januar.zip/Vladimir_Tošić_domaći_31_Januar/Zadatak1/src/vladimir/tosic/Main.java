package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		/*
		 * 1. Napisati program koji će generisati i ispisati po jedan broj sledećih
		 * tipova: Int, Float, Boolean(Long?), Double, Byte.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite broj.");
		byte broj = sc.nextByte();
		int ceo = (int) broj + 20;
		long dug = (long) ceo + 123456879;
		float n = (float) dug + 10.5f;
		double realan = (double) n + 15.8;
		
		System.out.println("Byte: " + broj);
		System.out.println("Int: " + ceo);
		System.out.println("Long: " + dug);
		System.out.println("Float: " + n);
		System.out.println("Double: " + realan);
		
		sc.close();
		
		

	}

}
