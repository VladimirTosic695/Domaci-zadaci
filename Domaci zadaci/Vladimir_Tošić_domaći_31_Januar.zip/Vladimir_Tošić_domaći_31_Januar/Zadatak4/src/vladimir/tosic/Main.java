package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 4. Napisati program koji računa broj parnih i neparnih brojeva u nizu.
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite dimenziju niza");
		int dimenzija = sc.nextInt();
		
		int niz [] = new int [dimenzija];
		int parni = 0, neparni = 0;
		
		System.out.println("Unesite elemente niza.");
		for(int i = 0; i < niz.length; i++) {
			System.out.print( (i+1) + ". element: ");
			niz[i] = sc.nextInt();
		}
		
		for(int i = 0; i < niz.length; i++) {
			if(niz[i] % 2 == 0)
				parni++;
			else
				neparni++;
		}
		
		System.out.println("Unutar niza parnih brojeva ima: " + parni);
		System.out.println("Unutar niza neparnih brojeva ima: " + neparni);
		
		sc.close();

	}

}
