package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	// 6. Napisati program koji pretvara dekadni broj {0,1,2,3,4,5,6,7,8,9} u binarni{0,1}.
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite broj.");
		int broj = sc.nextInt();
		
		int temp = broj;
		
	
		String binarni = "";
		String s = "";
		
		
		while(broj != 0) {
			int ostatak = broj % 2;
			broj = broj / 2;
			s += String.format("%d", ostatak);
		}
		
		for(int i = s.length() - 1; i >= 0; i--) {
			binarni += s.charAt(i);
		}
		
		
		System.out.println("Dekadni broj: " + temp + "\nBinarni: " + binarni);
		
		sc.close();
		
		

	}

}
