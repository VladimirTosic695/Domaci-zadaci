package vladimir.tosic;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 5. a) Kreirati dinamički niz.
		// b) Unutar niza dodati 10 imena, koristeći ugrađenu metodu.
		// c) Ispisati sadržaj niza.
		// d) Na poziciji 5 dodati novo ime.
		// e) Odštampati trenutni sadržaj niza.
		// f) Obrisati jedno ime.
		// g) Odštampati trenutni sadržaj niza
		
		
		List<String> dinamickiNiz = new ArrayList<String>();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite 10 imena.");
		for(int i = 0; i < 10; i++) {
			System.out.print((i+1) + ". ime: ");
			String ime = sc.nextLine();
			dinamickiNiz.add(ime);
		}
		
		System.out.println("\nLista imena: ");
		for(String ime : dinamickiNiz) {
			System.out.printf("%3s ", ime);
		}
		
		dinamickiNiz.add(4, "novoIme");
		
		System.out.println("\nLista imena: ");
		for(String ime : dinamickiNiz) {
			System.out.printf("%3s ", ime);
		}
		
		dinamickiNiz.remove("Pera");
		
		System.out.println("\nLista imena: ");
		for(String ime : dinamickiNiz) {
			System.out.printf("%3s ", ime);
		}
		
		sc.close();

	}

}
