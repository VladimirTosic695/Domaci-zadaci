package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 9. Napisati program koji prebrojava “space” simbole.
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Upisite recenicu.");
		String rec = sc.nextLine();
		
		int brojac = 0;
		
		for(int i = 0; i < rec.length(); i++) {
			if(rec.charAt(i) == ' ')
				brojac++;
		}
		
		System.out.println("Unutar zadate recenice ima " + brojac + " “space” simbola.");
		
		sc.close();

	}

}
