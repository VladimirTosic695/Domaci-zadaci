package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		/*
		 * 10. Napisati program koji omogućuje unos 10 brojeva unutar niza, traženog
		 * broja, a zatim je potrebno ispisati koliko puta se traženi broj pojavljuje u
		 * nizu.
		 */
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite broj da bismo proverili koliko puta se pojavljuje u nizu.");
		int broj = sc.nextInt();
		
		int brojac = 0;
		
		int niz[] = new int [10];
		
		System.out.println("Unesite brojeve koje ce sadrzati niz!");
		for(int i = 0; i < 10; i++) {
			System.out.print("Broj: ");
			niz[i] = sc.nextInt();
			if(niz[i] == broj) {
				brojac++;
			}
		}
		if(brojac == 1) {
			System.out.println("Trazeni broj se javlja jedanput u nizu");
		} else {
		System.out.println("Trazeni broj se javlja " + brojac + " puta unutar niza.");
		}
		
		sc.close();

	}

}
