package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
	// 2. Napisati program koji generiše i ispisuje pet slučajna broja celobrojnog tipa.
		
		System.out.println("Pet nasumicnih celih brojeva");
		for(int i = 1; i <=5; i++) {
			double a = Math.random() * 100;
			System.out.println(i + ". broj = " + (int) a);
		}
		
		
		
	}

}
