package vladimir.tosic;

import java.util.Scanner;

public class Main {
	
	public static int suma(int broj) {
		if(broj == 0)
			return 0;
		else {
			return (broj % 10) + suma(broj / 10);
		}
	}
	
	public static void main(String[] args) {
		/* 8. Koristeći rekurzivan postupak izračunati sumu svih cifara unetog broja.
		 */
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite broj.");
		int broj = sc.nextInt();
		
	
		System.out.println("Suma cifara unetog broja: " + suma(broj));
		
		sc.close();
		
	}

}
