package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		// 3. Napisati program koji ispisuje sve proste brojeve od 1 do 10.
		// Prost broj je deljiv samo jedinicom i samim sobom.
		
		boolean broj = true;
		int i, j;
		
		for(i = 2; i <= 10; i++) {
			broj = true;
			for(j = 2; j < i; j++) {
				if(i % j == 0) 
					broj = false;
			}
			if(broj) {
				System.out.println(i + " je prost broj.");
			} else {
				System.out.println("Broj " + i + " nije prost broj.");
			}
		}
		
		

	}

}
