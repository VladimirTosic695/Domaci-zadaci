package vladimir.tosic;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		// 7. Programski kreirati fajl i upisati tekst: Ja sam programer!
		
		DataInputStream dis = new DataInputStream(System.in);
		
		FileOutputStream fos = new FileOutputStream("unos.txt");
		
		char s;
		
		System.out.println("Unos prekinite unosom cifre 1. Unesite recenicu: "
				+ "“Ja sam programer!”, a zatim prekinite unos.");
		
		while((s = (char) dis.read()) != '1') {
			
			fos.write(s);
			
		}
		
		fos.close();
		

	}

}
