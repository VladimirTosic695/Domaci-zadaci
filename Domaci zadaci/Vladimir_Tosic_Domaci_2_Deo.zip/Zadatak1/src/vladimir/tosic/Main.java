package vladimir.tosic;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#.##");
		System.out.println("Unesite vrednost a");
		double a = sc.nextDouble();
		System.out.println("Unesite vrednost b");
		double b = sc.nextDouble();
		System.out.println("Unesite vrednost c");
		double c = sc.nextDouble();
		
		double f, g, zbir, razlika;
		
		g = (a + b + Math.sin(a)) * Math.cos(c);
		
		f = (a-b) / (c + a /(c + b /(c-b)));
		
		zbir = g + f;
		
		razlika = f - g;
		
		System.out.println("Zbir funkcija f i g: " + df.format(zbir));
		System.out.println("Razlika funkcija f i g: " + df.format(razlika));
		
		sc.close();
		

	}

}
