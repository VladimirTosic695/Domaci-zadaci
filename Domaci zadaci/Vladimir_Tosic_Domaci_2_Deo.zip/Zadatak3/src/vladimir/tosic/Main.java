package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite vrednost x");
		double x = sc.nextDouble();
		
		double y;
		
		if(x < 5) {
			y = Math.pow(x - 3, 2);
		} else if(x >= 8) {
			y = x - 1;
		} else {
			y = x + 2;
		}
		
		System.out.println("Vrednost funkcije Y = " + y);

		sc.close();
	}

}
