package vladimir.tosic;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
	
	public static double [] b(double x[], double f[], int n){
		
		double s1 = 0, s2 = 0, s3 = 0, s4 = 0;
		double b[] = new double [n];
		
		for(int i = 1; i < n; i++) {
			s1 += Math.log(x[i]);
			s2 += Math.log(f[i]);
			s3 += Math.log(x[i]) * Math.log(f[i]);
			s4 += Math.pow(Math.log(x[i]), 2);
		}
		
		b[1] = (s1 * s2 - n * s3) / (Math.pow(s1, 2) - n * s4);
		b[0] = Math.exp((s2 - b[1] * s4) / n);
		
		return b;
		
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#.###");
		
		
		System.out.println("Unesite n");
		int n = sc.nextInt();
		
		double x[] = new double [n];
		double f[] = new double [n];
		
		double y[] = new double [n];
		
		for(int k = 0; k < n; k++) {
			System.out.println("x["+k+"] = ");
			x[k] = sc.nextDouble();
			System.out.println("f["+k+"] = ");
			f[k] = sc.nextDouble();
		}
		
		for(int k = 0; k < n; k++) {
			y[k] = b(x, f, n)[0] * Math.pow(x[k], b(x, f, n)[1]);
		}
		
		System.out.println("X\tY(X)");
		for(int k = 0; k < n; k++) {
			System.out.println(x[k] + "\t" + df.format(y[k]));
		}
		sc.close();
	}

}
