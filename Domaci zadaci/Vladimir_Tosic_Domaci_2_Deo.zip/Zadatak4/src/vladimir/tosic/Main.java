package vladimir.tosic;

import java.text.DecimalFormat;

public class Main {

	public static void main(String[] args) {
		
		DecimalFormat df = new DecimalFormat("#.##");
		double z;
		int brojac = 0;
		
		System.out.println("R.BR.\tX\ta\ty\tz");
		for(double x = 1; x <= 4; x++) {
			for(double a = 0.1; a <= 0.5; a += 0.1)
				for(double y = 0.5; y >= 0.2; y -= 0.05) {
					z = Math.pow((x + a + y) / (x-y), 2) - x / (x+a);
					brojac++;
					System.out.println(brojac + "\t" + df.format(x) + "\t" + df.format(a) + "\t" + df.format(y) + "\t" + df.format(z));
				}
		}

	}

}
