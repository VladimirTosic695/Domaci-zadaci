package vladimir.tosic;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("#.###");
		
		System.out.println("Unesite duzinu niza n");
		int n = sc.nextInt();
		
		double a[] = new double [2*n+1];
		double b[] = new double [n+1];
		
		System.out.println("Unesite elemente niza A");
		for(int i = 1; i <= 2*n; i++) {
			System.out.print("A["+i+"] = ");
			a[i] = sc.nextDouble();
		}
		
		// Ispisivanje elemenata niza a
		System.out.println("Elementi niza A: ");
		for(int i = 1; i <= 2*n; i++) {
			System.out.print(a[i] + " ");
		}
		
		// Formiranje niza B
		for(int i = 1; i <= n; i++) {
			b[i] = (a[i] + a[2*n+1-i]) / 2;
		}
		
		// Ispisivanje niza B
		System.out.println("\nElementi niza B: ");
		for(int i = 1; i <= n; i++) {
			System.out.print("B["+i+"] = " + df.format(b[i]) + "\n");
		}
		sc.close();
	}

}
