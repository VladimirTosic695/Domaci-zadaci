package vladimir.tosic;

import java.text.DecimalFormat;

public class Main {
	
	public static double izracunaj(double x,double y, double f) {
		
			if(x < y) {
					f = Math.exp(x) * Math.cos(3 * y);
				}
			if(x == y) {
					f = Math.sin(x);
				}
			if(x > y) {
					f = 1 + Math.sqrt(Math.abs(x * y));
				}
	
		return f;
	}

	public static void main(String[] args) {
		
		DecimalFormat df = new DecimalFormat ("##.###");
	
		double f = 0;
		
		System.out.println("X\tY\tF(X,Y)");
		for(double x = 0.1; x <= 0.5; x+=0.1) {
			for(double y = 0.01; y <= 0.03; y += 0.01) {
				
				System.out.println(df.format(x) + "\t" + df.format(y) + "\t" + df.format(izracunaj(x, y, f)));
			}
		}

	}

}
