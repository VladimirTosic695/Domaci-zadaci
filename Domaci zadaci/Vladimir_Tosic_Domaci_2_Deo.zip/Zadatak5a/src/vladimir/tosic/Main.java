package vladimir.tosic;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		DecimalFormat df = new DecimalFormat("#.##");

		System.out.println("Unesite vrednost za epsilon");
		double epsilon = sc.nextDouble();

		double a;
		do {
			System.out.println("Unesite vrednost a");
			a = sc.nextDouble();
			if (a <= 0) {
				System.out.println("Uneli ste negativan broj. Unesite ponovo vrednost a");
			}
		} while (a <= 0);
		System.out.println("Unesite vrednost n");
		double n = sc.nextDouble();

		double x0 = (a + n - 1) / n;
		double x1 = ((n - 1) * x0 + a / Math.pow(x0, n - 1)) / n;

		while (Math.abs(x1 - x0) > epsilon) {
			x0 = x1;
			x1 = ((n - 1) * x0 + a / Math.pow(x0, n - 1)) / n;
		}
		System.out.println("X = " + df.format(x1));
		sc.close();
	}

}
