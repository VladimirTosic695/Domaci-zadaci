package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite duzinu niza");
		int n = sc.nextInt();

		
		double p = 1;
		
		for(double i = 1; i <= n; i++) {
			p *= (1 - 1 / (i + 1));
		}
	
		System.out.println("P = " + p);
		
		sc.close();

	}

}
