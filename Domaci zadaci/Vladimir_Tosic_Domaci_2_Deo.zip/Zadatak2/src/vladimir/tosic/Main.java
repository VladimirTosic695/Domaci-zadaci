package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		// Zadatak 2. Sastaviti algoritam i napisati program kojim se za zadati trocifren broj:
		
		// 1. izračunava proizvod cifara,
		
		// 2. izračunava suma kubova cifara,
		
		// 3. određuje broj koji se dobija ispisom cifara u obrnutom redosledu.
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite trocifreni broj");
		int broj = sc.nextInt();
		
		int st,d,j;
		st = broj / 100;
		d = broj / 10 % 10;
		j = broj % 10;
		
		int p = 1;
		int s = 0, kub = 0;
		while(broj != 0) {	
			if(broj != 0) {
			int a = broj % 10;
			p = p * a;
			kub = a*a*a;
			s += kub;
			}
			broj = broj / 10;				
		}
		
		
		
		System.out.println("Proizvod cifara trocifrenog broja: " + p);
		System.out.println("Suma kubova cifara trocifrenog broja: " + s);
		System.out.println("Trocifreni broj unazad: " + j + d + st);
		
		sc.close();

	}

}
