package vladimir.tosic;

public class Tacka {
	
	private double masa;
	private double x, y, z;
	final double gama = 6.67 * 10e-11;
	
	Tacka(){
		masa = 1;
		x = y = z = 0;
	}
	
	Tacka(double masa, double xx, double yy, double zz){
		this.masa = masa;
		x = xx;
		y = yy;
		z = zz;
	}
	
	public double rastojanje(Tacka t) {
		return Math.sqrt(Math.pow(x - t.x, 2) + Math.pow(y - t.y, 2) + Math.pow(z - t.z, 2));
	}
	
	public double privlacnaSila(Tacka t) {
		return gama * masa * t.masa / Math.pow(rastojanje(t), 2);
	}
	
	public String ispisTacke() {
		return "Masa: " + masa + "(x, y, z): " + x + "," + y + "," + z;
	}

}
