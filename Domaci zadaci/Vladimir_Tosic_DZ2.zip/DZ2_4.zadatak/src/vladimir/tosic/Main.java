package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		
		Tacka tacka1 = new Tacka(2.6, 3, 2, 3);
        Tacka tacka2 = new Tacka(5.4, 4, 3, 3);
        Tacka tacka3 = new Tacka(3.8, 2, 5, 7);
    	Tacka tacka4 = new Tacka(1, 4, 1, 3);
        Tacka tacka5 = new Tacka(3, 5, 3, 1);
        Tacka tacka6 = new Tacka(33, 2, 8, 7);
        
        System.out.println("Rastojanje: " +tacka1.rastojanje(tacka3));
        System.out.println("Privlacna sila: " + tacka1.privlacnaSila(tacka3));
        System.out.println(tacka1.ispisTacke());
        
        Niz n = new Niz();
        
        n.dodajTacku(tacka3);
        n.dodajTacku(tacka1);
        n.dodajTacku(tacka2);
        System.out.println("\nIspisivanje niza tacaka: ");
        n.ispisiNizTacaka();
        
        n.dodajTacku(tacka4);
        n.dodajTacku(tacka5);
        n.dodajTacku(tacka6);
        System.out.println("\nIspisivanje niza tacaka nakon prosirenja kapaciteta: ");
        n.ispisiNizTacaka();
        
     

	}

}
