package vladimir.tosic;

public class Niz {
	
	Tacka nizTacaka[];
	private int kapacitet;
	private int indeks;
	
	Niz(){
		kapacitet = 5;
		nizTacaka = new Tacka[kapacitet];
		indeks = 0;
	}
		
	public void dodajTacku(Tacka t) {
			if(indeks == kapacitet) {
				Tacka noviNiz[] = new Tacka[kapacitet + 5];
				for(int i = 0; i < indeks; i++) {
					noviNiz[i] = nizTacaka[i];
				}
				kapacitet += 5;
				nizTacaka = noviNiz;
			}
			if(nizTacaka[indeks] == null) {
				nizTacaka[indeks] = t;
				this.indeks++;
			}
	}
	
	public int getBrojTacaka() {
		int brojac = 0;
		for(Tacka t : nizTacaka) {
			if(t != null) {
				brojac++;
			}
		}
		return brojac;
	}
	
	public Tacka tackaKojaNajvisePrivlaci(Tacka t) {
		double pomocna = 0;
		Tacka trazena = nizTacaka[0];
		for(int i = 0; i < nizTacaka.length; i++) {
			if(nizTacaka[i].privlacnaSila(t) > pomocna) {
				pomocna = nizTacaka[i].privlacnaSila(t);
				trazena = nizTacaka[i];
			}
		}
		return trazena;
	}
	
	public void ispisiNizTacaka() {
		for(int i = 0; i < nizTacaka.length; i++) {
			if(nizTacaka[i] != null)
				System.out.println(nizTacaka[i].ispisTacke());
		}
	}

}
