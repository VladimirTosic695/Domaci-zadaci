package vladimir.tosic;

public class Saobracajnica {

	private String ime;
	private double duzina;
	
	Saobracajnica(){
		
	}

	public Saobracajnica(String ime, double duzina) throws Izuzetak {
		if (ime.length() > 30) {
			throw new Izuzetak("Ime ne moze imati vise od 30 karaktera.");
		} else
			this.ime = ime;
		this.duzina = duzina;
	}

	public double getDuzina() {
		return duzina;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) throws Izuzetak {
		if (ime.length() > 30) {
			throw new Izuzetak("Ime ne moze imati vise od 30 karaktera.");
		} else
			this.ime = ime;
	}

	public void ispisSaobracajnice() {
		System.out.print(ime + "(" + duzina + " m)");
	}

}
