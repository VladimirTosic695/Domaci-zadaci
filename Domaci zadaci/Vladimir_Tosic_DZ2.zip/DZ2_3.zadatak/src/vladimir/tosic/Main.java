package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		
		
		try {
		
		Saobracajnica s = new Saobracajnica("Milos Veliki", 156054);
		// Provera saobracajnice
		s.ispisSaobracajnice();
		
		StambenaZgrada st = new StambenaZgrada(280, 3, 4);
		StambenaZgrada st2 = new StambenaZgrada(300, 2, 4);
		
		StambenaZgrada st3 = new StambenaZgrada(500, 6, 6);
		StambenaZgrada st4 = new StambenaZgrada(1000, 8, 4);
		
		// Ispisivanje podataka o zgradi (povrsina/broj spratova/broj stanova)
		System.out.println();
		st.ispisZgrade();
		
		System.out.println("Prosecna povrsina stana u prvoj zgradi: " + st.prosecnaPovrsinaStana());
		
		// Pravljenje dve ulice i dodavanje zgrada u njih
		Ulica ulica1 = new Ulica("Sremska", 300, 5);
		Ulica ulica2 = new Ulica("Gajeva", 500, 10);
		ulica1.dodajZgradu(2, st);
		ulica1.dodajZgradu(3, st2);
		
		ulica2.dodajZgradu(5, st3);
		ulica2.dodajZgradu(7, st4);

		// Naselje koje se sastoji iz dve ulice sa po dve zgrade
		Ulica naselje[] = new Ulica[2];
		
		naselje[0] = ulica1;
		naselje[1] = ulica2;
		
		System.out.println();
		
		//Ispisivanje podataka o naselju
		int brojac = 1;
		for(Ulica u : naselje) {
			System.out.println(brojac + ". ulica: ");
			u.ispisUlice();
			brojac++;
		}
		
		
		} catch (Izuzetak e) {
			System.out.println(e.getMessage());
		}

	}

}
