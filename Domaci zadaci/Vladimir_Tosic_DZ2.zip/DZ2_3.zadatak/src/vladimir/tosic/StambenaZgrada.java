package vladimir.tosic;

public class StambenaZgrada {
	
	private double povrsinaOsnove;
	private int brojSpratova;
	private int brojJedinicaPoSpratu;
	
	public StambenaZgrada(double osnova, int spratovi, int stanovi) {
		povrsinaOsnove = osnova;
		brojSpratova = spratovi;
		brojJedinicaPoSpratu = stanovi;
	}
	
	public double getPovrsinaOsnove() {
		return povrsinaOsnove;
	}
	
	public int getBrojSpratova() {
		return brojSpratova;
	}
	
	public int getBrojStanova() {
		return brojJedinicaPoSpratu;
	}
	
	public int ukupanBrojStanova() {
		return brojJedinicaPoSpratu * brojSpratova;
	}
	public double prosecnaPovrsinaStana() {
		return povrsinaOsnove / brojJedinicaPoSpratu;
	}
	
	public void ispisZgrade() {
		System.out.println(povrsinaOsnove + " m2/" + brojSpratova + "/" + brojJedinicaPoSpratu);
	}

}
