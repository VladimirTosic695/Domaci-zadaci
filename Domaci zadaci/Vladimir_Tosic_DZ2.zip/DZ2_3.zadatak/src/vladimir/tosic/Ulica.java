package vladimir.tosic;

public class Ulica extends Saobracajnica {
	
	private StambenaZgrada nizZgrada[];
	private int maksAdresniBroj;
	
	Ulica(String ime, double duzina, int maksBroj) throws Izuzetak {
		super(ime, duzina);
		maksAdresniBroj = maksBroj;
		nizZgrada = new StambenaZgrada[maksBroj];
	}
	
	public void dodajZgradu(int adrBroj, StambenaZgrada s) throws Izuzetak {
		
		if (adrBroj >= maksAdresniBroj) {
			throw new Izuzetak("Zgrada sa zadatim brojem ne postoji. Adresni broj poslednje zgrade u ulici je " + maksAdresniBroj);
		} else if(nizZgrada[adrBroj] != null) {
			throw new Izuzetak("Na ovom adresnom broju vec postoji zgrada.");
		} else {	
			nizZgrada[adrBroj] = s;
		}
	}
	
	public int ukupanBrojZgrada() {
		int brojac = 0;
		for(int i = 0; i < maksAdresniBroj; i++) {
			if(nizZgrada[i] != null)
				brojac++;
		}
		return brojac;
	}
	
	public double ukupnaPovrsinaZgrada() {
		double suma = 0;
		for(int i = 0; i < nizZgrada.length; i++) {
			if(nizZgrada[i] != null) {
				suma += nizZgrada[i].prosecnaPovrsinaStana() * nizZgrada[i].ukupanBrojStanova();
			}
		}
		return suma;
	}
	
	public void ispisUlice() {
		System.out.print("U ulici ");
		super.ispisSaobracajnice();
		System.out.println(" ima " + ukupanBrojZgrada() + " zgrade sa ukupnom povrsinom stanova od " + ukupnaPovrsinaZgrada());
	}

}
