package vladimir.tosic;

public class Izuzetak extends Exception {
	
	public Izuzetak(String poruka) {
		super(poruka);
	}

}
