package vladimir.tosic;

public class Student {

	private String ime;
	private int indeks;
	private int kapacitet;
	private Ispit niz[];

	Student(String ime, int indeks) {
		this.ime = ime;
		this.indeks = indeks;
		kapacitet = 40;
		niz = new Ispit[kapacitet];
	}

	Student(String ime, int indeks, int kapacitet) {
		this.ime = ime;
		this.indeks = indeks;
		niz = new Ispit[kapacitet];
	}

	public int imaLiMestaUNizu() {
		int brojac = 0;
		for (int i = 0; i < niz.length; i++) {
			if (niz[i] != null) {
				brojac++;
			}
		}
		return kapacitet - brojac;
	}

	public void dodajIspit(Ispit ispit) {
		int brojac = 0;
		for (int i = 0; i < niz.length; i++) {
			if (niz[i] != null) {
				brojac++;
			}
		}
		if (brojac == kapacitet)
			System.out.println("Niz je pun! Ne mozete dodati vise ispita.");
		else
			niz[brojac] = ispit;
	}

	public double srednjaOcena() {
		double suma = 0;
		int brojac = 0;
		for (int i = 0; i < niz.length; i++) {
			if (niz[i] != null) {
				if (niz[i].dohvatiOcenu().dohvatiOcenuBrojcano() > 5) {
					suma += niz[i].dohvatiOcenu().dohvatiOcenuBrojcano();
					brojac++;
				}
			}
		}
		return suma / brojac;
	}

	public String getIme() {
		return ime;
	}

	public int getIndeks() {
		return indeks;
	}

	public String ispisStudenta() {
		return ime + "[" + getIndeks() / 10000 + "/" + getIndeks() % 10000 + ":" + srednjaOcena() + "]";
	}

}
