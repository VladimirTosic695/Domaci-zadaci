package vladimir.tosic;

public class Main {

	public static void main(String[] args) {

		Ocena o = new Ocena(4);
		Ocena o1 = new Ocena(7);
		Ocena o2 = new Ocena(11);

		// Ispisivanje oba oblika ocene
		System.out.println("Ocena: " + o.ispisOcene());
		System.out.println("Ocena: " + o1.ispisOcene());
		System.out.println("Ocena: " + o2.ispisOcene());

		try {
			Ispit biologija = new Ispit("bio987", o);
			Ispit ekologija = new Ispit("eko156", o1);
			Ispit matematika = new Ispit("mat314", o2);

			// Ispisivanje ispita "sifra:ocena"
			System.out.println("\nIpisivanje ispita: ");
			System.out.println(ekologija.opisIspita());

			Student vladimir = new Student("Vladimir", 20126593);

			vladimir.dodajIspit(matematika);
			vladimir.dodajIspit(ekologija);
			vladimir.dodajIspit(biologija);

			System.out.println("\nStudentu se moze dodati jos " + vladimir.imaLiMestaUNizu() + " ispita.");
			System.out.println("Prosecna ocena studenta: " + vladimir.srednjaOcena());
			System.out.println("Podaci o studentu: " + vladimir.ispisStudenta());

		} catch (Exception e) {
			System.out.println("Maks karaktera za sifru je 6");
		}

	}

}
