package vladimir.tosic;

public class Ocena {

	private int Ocenabrojcano;
	private String opisnaOcena;

	Ocena(int ocenaBroj) {
		if (ocenaBroj < 5)
			Ocenabrojcano = 5;
		else if (ocenaBroj > 10)
			Ocenabrojcano = 10;
		else
			Ocenabrojcano = ocenaBroj;

		switch (Ocenabrojcano) {
		case 5: {
			this.opisnaOcena = "Pet";
			break;
		}
		case 6: {
			this.opisnaOcena = "Šest";
			break;
		}
		case 7: {
			this.opisnaOcena = "Sedam";
			break;
		}
		case 8: {
			this.opisnaOcena = "Osam";
			break;
		}
		case 9: {
			this.opisnaOcena = "Devet";
			break;
		}
		case 10: {
			this.opisnaOcena = "Deset";
			break;
		}
		}
	}

	public int dohvatiOcenuBrojcano() {
		return Ocenabrojcano;
	}

	public String ispisOcene() {
		return Ocenabrojcano + "(" + opisnaOcena + ")";
	}

}
