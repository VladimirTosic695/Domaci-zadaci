package vladimir.tosic;

public class Ispit {

	private String sifraIspita;
	private Ocena grade;

	Ispit(String sifra, Ocena grade) throws Exception {
		if (sifra.length() <= 6)
			sifraIspita = sifra;
		else
			throw new Exception();
		this.grade = grade;
	}

	public String dohvatiSifru() {
		return sifraIspita;
	}

	public Ocena dohvatiOcenu() {
		return grade;
	}

	public String opisIspita() {
		return "Sifra ispita: " + sifraIspita + "\nOcena: " + grade.ispisOcene();
	}

}
