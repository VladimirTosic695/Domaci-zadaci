package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		
		Predmet p1 = new Predmet("Knjiga1",250);
		Predmet p2 = new Predmet("Knjiga2",150);
		Predmet p3 = new Predmet("Knjiga3",350);
		Predmet p4 = new Predmet("Knjiga4",50);
		Predmet p5 = new Predmet("Knjiga5",100);
		
		Polica polica = new Polica(8, 2000);
		
		polica.dodavanjePredmeta(p1);
		polica.dodavanjePredmeta(p2);
		polica.dodavanjePredmeta(p3);
		polica.dodavanjePredmeta(p4);

		System.out.println("Ukupan teret na polici: " + polica.ukupanTeret());
		
		polica.postaviPredmet(4, p5);
		
		System.out.println("Da li na polici ima prazno mesto? " + polica.praznoMesto());
		System.out.println("Koliko tereta jos mozemo dodati na policu? " + polica.kolikoJosTereta());
		
		System.out.println();
		polica.StanjeNaPolici();
		
		System.out.println("\n\nOpis!");
		polica.opis();
		

	}

}
