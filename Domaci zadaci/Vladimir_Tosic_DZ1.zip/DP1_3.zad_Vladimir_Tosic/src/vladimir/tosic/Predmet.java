package vladimir.tosic;

public class Predmet {
	
	String ime;
	double tezinaPredmeta;
	
	Predmet(){
		
	}
	
	Predmet(String ime,double tezina) {
		this.ime = ime;
		tezinaPredmeta = tezina;
	}
	
	public void setTezinaPredmeta(double tezina) {
		tezinaPredmeta = tezina;
	}

	public double getTezinaPredmeta() {
		return tezinaPredmeta;
	}
	
	
	public String toString() {
		return "Ime: " + ime + "\tTezina predmeta: " + tezinaPredmeta;
	}

}
