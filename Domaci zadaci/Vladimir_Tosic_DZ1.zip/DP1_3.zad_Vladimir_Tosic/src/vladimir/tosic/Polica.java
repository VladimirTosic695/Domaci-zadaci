package vladimir.tosic;

import java.util.ArrayList;
import java.util.List;

public class Polica extends Predmet {
	
	
	int kapacitet;
	double nosivost;
	List<Predmet> spisakPredmeta = new ArrayList<Predmet>();
	
	
	Polica(int kapacitet, double nosivost){
		this.kapacitet = kapacitet;
		this.nosivost = nosivost;
	}
	
	public void dodavanjePredmeta(Predmet ob) {
			spisakPredmeta.add(ob);
	}
	public Predmet pristupPredmetu(int indeks) {
		return spisakPredmeta.get(indeks);
	}
	
	public double ukupanTeret() {
		double ukupnaTezina = 0;
		for(Predmet p : spisakPredmeta) {
			ukupnaTezina = ukupnaTezina + p.tezinaPredmeta;
		}
		return ukupnaTezina;
	}
	
	public void uzmiPredmet(int indeks) {
		 spisakPredmeta.remove(indeks);
	}
	public void postaviPredmet(int indeks, Predmet ob) {
		spisakPredmeta.add(indeks, ob);
	}
	
	public void isprazniPolicu() {
		spisakPredmeta.clear();
	}
	
	public boolean praznoMesto() {
		boolean prazno;
		if(kapacitet > spisakPredmeta.size()) {
			prazno = true;
		} else {
				prazno = false;
			}
		return prazno;
		}
	public double kolikoJosTereta() {
		return nosivost - ukupanTeret();
	}
	
	public int getKapacitet() {
		return kapacitet;
	}	
	public double getBrojPopunjenihMesta() {	
		return spisakPredmeta.size();
	}
	public double getNosivost() {
		return nosivost;
	}
	public void StanjeNaPolici() {
		System.out.println("Kapacitet: " + kapacitet);
		System.out.println("Broj popunjenih mesta: " + spisakPredmeta.size());
		System.out.println("Nosivost: " + nosivost);
		System.out.println("Ukupan teret na polici: " + ukupanTeret());
		System.out.println("Koliko jos moze da se doda: " + kolikoJosTereta());
	}
	
	
	public void opis() {
		System.out.println(spisakPredmeta + "\nKapcitet police: " + kapacitet + "\nNosivost police: " + nosivost + 
				"\nUkupan teret na polici: " + ukupanTeret() + "\nKoliko jos tereta se moze staviti na policu? " 
				+ kolikoJosTereta() + "\nBroj popunjenih mesta na polici: " + spisakPredmeta.size() + " od " + kapacitet);
	}
	
	
	

}
