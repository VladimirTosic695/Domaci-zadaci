package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		
		//Kreiranja objekata klase Vektor
		Vektor v1 = new Vektor();
		Vektor v2 = new Vektor(5);
		Vektor v3 = new Vektor(2, 4);
		Vektor v4 = new Vektor(5);
			
		System.out.println("Vektor v1: ");
		v1.setVrednost(3, 5.5);
		v1.setVrednost(1, 1.1);
		v1.setVrednost(10, 7.5);
		
		System.out.println("Vrednost prvog indeksa: " + v1.getVrednost(1) + "\nVrednost treceg indeksa:" + v1.getVrednost(3));
		System.out.println("Donja granicna vrednost " + v1.donjaGranicnaVrednost());
		System.out.println("Gornja granicna vrednost " + v1.gornjaGranicnaVrednost());
		
		v1.ispisBrojeva();
		
		System.out.println("\n\nVektor v2: ");
		
		v2.setVrednost(1, 11.1);
		v2.setVrednost(2, 12.1);
		v2.setVrednost(3, 13.2);
		v2.setVrednost(4, 14.2);
		v2.setVrednost(5, 15.5);
		
		System.out.println("Vrednost prvog indeksa: " + v2.getVrednost(1)+ "\nVrednost treceg indeksa:" + v2.getVrednost(3));
		System.out.println("Donja granicna vrednost " + v2.donjaGranicnaVrednost());
		System.out.println("Gornja granicna vrednost " + v2.gornjaGranicnaVrednost());
		
		v2.ispisBrojeva();
		
		System.out.println("\n\nVektor v3: ");
		
		v3.setVrednost(2, 22.1);
		v3.setVrednost(3, 23.2);
		v3.setVrednost(4, 24.2);

		System.out.println("Vrednost treceg indeksa: " + v3.getVrednost(3));
		System.out.println("Donja granicna vrednost " + v3.donjaGranicnaVrednost());
		System.out.println("Gornja granicna vrednost " + v3.gornjaGranicnaVrednost());
		
		v3.ispisBrojeva();
		
		System.out.println("\n\nVektor v4: ");
		
		v4.setVrednost(1, 18.2);
		v4.setVrednost(2, 2.5);
		v4.setVrednost(3, 6.3);
		v4.setVrednost(4, 4.8);
		v4.setVrednost(5, 9.9);
		
		System.out.println("Vrednost prvog indeksa: " + v3.getVrednost(1));
		System.out.println("Donja granicna vrednost " + v3.donjaGranicnaVrednost());
		System.out.println("Gornja granicna vrednost " + v3.gornjaGranicnaVrednost());
		
		v4.ispisBrojeva();
		
		System.out.println("\n\nSkalarni proizvod vektora v3 i v1: " + v3.skalarniProizvodVektora(v1));
		System.out.println("Skalarni proizvod vektora v3 i v2: " + v3.skalarniProizvodVektora(v2));
		System.out.println("Skalarni proizvod vektora v3 i v4: " + v3.skalarniProizvodVektora(v4));
		
		System.out.println("Skalarni proizvod vektora v2 i v1: " + v2.skalarniProizvodVektora(v1));
		System.out.println("Skalarni proizvod vektora v2 i v4: " + v2.skalarniProizvodVektora(v4));
		
		System.out.println("Skalarni proizvod vektora v4 i v1: " + v4.skalarniProizvodVektora(v1));
	}

}
