package vladimir.tosic;

public class Vektor {
	
	double vektori [];
	int donjaGranica, gornjaGranica;
	
	public Vektor() {
		vektori = new double[11];
		donjaGranica = 1;
		gornjaGranica = 10;
	}
	
	public Vektor(int gornjaGranica) {
		vektori = new double[gornjaGranica + 1];
		donjaGranica = 1;
		this.gornjaGranica = gornjaGranica;
	}
	
	Vektor(int donjaGranica, int gornjaGranica) {
		vektori = new double[gornjaGranica - donjaGranica + 3];
		this.donjaGranica = donjaGranica;
		this.gornjaGranica = gornjaGranica;
	}
	
	public void setVrednost(int i, double vrednost) {
		vektori[i] = vrednost;
	}
	
	public double getVrednost(int indeks) {
		return vektori[indeks];
	}
	
	public double gornjaGranicnaVrednost() {
		return vektori[gornjaGranica];
	}
	
	public double donjaGranicnaVrednost() {
		return vektori[donjaGranica];
	}
	
	public double skalarniProizvodVektora(Vektor ob) {
		double proizvod = 0;
		for(int i = 0; i <= gornjaGranica; i++) {
			proizvod += vektori[i] * ob.vektori[i];
		}
		return proizvod;
	}
	
	
	public void ispisBrojeva() {
		System.out.println("Vrednosti vektora: ");
		for(int i = donjaGranica; i <= gornjaGranica; i++) {
		System.out.print(vektori[i] + "   ");
		}
	}

}
