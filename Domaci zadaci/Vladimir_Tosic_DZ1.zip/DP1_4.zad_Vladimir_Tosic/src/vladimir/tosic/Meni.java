package vladimir.tosic;

import java.util.ArrayList;
import java.util.List;

public class Meni {
	
	int kapacitet;
	List<Namirnica> meni = new ArrayList<Namirnica>();
	
	Meni(int k){
		kapacitet = k;
	}
	
	public void dodavanjeNamirnice(Namirnica nam) {
		meni.add(nam);
	}
	
	public double ukupnaEnergetska() {
		double energija = 0;
			for(Namirnica n : meni) {
				energija += n.izracunajEnerVred();
			}
		return energija;
	}
	
	public String toString() {
		return meni.toString() + "\nUkupna energetska vrednost: " + ukupnaEnergetska();
	}
	
	
	

}
