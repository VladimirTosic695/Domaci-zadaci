package vladimir.tosic;

public abstract class Namirnica extends Energent {
	
	String ime;
	double identifikator = Math.random() * 100;
	int ID = (int) identifikator;
	
	Namirnica(double energetskaVrednost, String ime) {
		super(energetskaVrednost);
		this.ime = ime;
	}
	Namirnica(String ime){
		this.ime = ime;
	}
	Namirnica(){
		
	}
	
	public String setIme(String ime) {
		return ime = this.ime;
	} 
	public String getImeNamirnice() {
		return ime;
	}
	public int getID() {
		return ID;
	}
	
	public abstract double izracunajEnerVred();
	
	public String toString() {
		return "Ime namirnice: " + ime + "\nID: " + ID;
	}
	
	

}
