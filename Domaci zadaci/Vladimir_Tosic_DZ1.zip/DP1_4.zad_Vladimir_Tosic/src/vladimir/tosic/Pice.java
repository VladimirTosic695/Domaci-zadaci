package vladimir.tosic;

public class Pice extends Namirnica {
	
	String ime;
	double kolicina, energija;
	
	
	Pice(){
		
	}
	Pice(double energija, String ime, double kolicina){
		super(energija, ime);
		this.energija = energija;
		this.kolicina = kolicina;
	}
	
	public double getKolicina() {
		return kolicina;
	}
	
	public double izracunajEnerVred() {
		return kolicina * this.energija;
	}
	
	public String toString() {
		return super.toString() + "\nKolicina: " + kolicina + "\nEnergetska vrednost: " + izracunajEnerVred();
	}

}
