package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		
		Hrana h1 = new Hrana("Biftek", 300, 65, 20, 15);
		Hrana h2 = new Hrana("Pirinac", 500, 28, 15, 65);
		
		System.out.println("Energetska vrednost: " + h1.izracunajEnerVred());
		System.out.println("Protein: " + h1.tezinskiUdeoBel() + " g.");
		System.out.println("Masti: " + h1.tezinskiUdeoMasti() + " g.");
		System.out.println("Seceri: " + h1.tezinskiUdeoSecera() + " g.");
		if(h1.zbirProcentualnihUdela() > 100) {
			System.out.println("Greska. Udeo ne moze biti veci od 100%.");
		} else {
		System.out.println("Zbir udela: " + h1.zbirProcentualnihUdela());
		}
		
		System.out.println(h1.toString());
		
		
		Pice p1 = new Pice(1200, "Sok", 1.5);
		Pice p2 = new Pice(800, "Vino", 0.75);
		
		System.out.println(p1.toString());
		
		
		Meni m = new Meni(15);
		
		m.dodavanjeNamirnice(h1);
		m.dodavanjeNamirnice(h2);
		m.dodavanjeNamirnice(p1);
		m.dodavanjeNamirnice(p2);
		
		System.out.println(m.toString());
		
		
		
		
	}

}
