package vladimir.tosic;

public class Hrana extends Namirnica {
	
	double tezina, udeoBel, udeoMasti, udeoSecera;
	
	Hrana(){
		
	}
	
	Hrana(String ime, double tezina, double protein, double masti, double secer){
		super(ime);
		this.tezina = tezina;
		udeoBel = protein;
		udeoMasti = masti;
		udeoSecera = secer;
	}
	
	public double tezinskiUdeoBel() {
		return udeoBel * tezina / 100;
	}
	public double tezinskiUdeoMasti() {
		return udeoMasti * tezina / 100;
	}
	public double tezinskiUdeoSecera() {
		return udeoSecera * tezina / 100;
	}
	
	public double izracunajEnerVred() {
		return tezinskiUdeoBel() * 16.7 + tezinskiUdeoMasti() * 37.6 + tezinskiUdeoSecera() * 17.2;
	}
	
	public double zbirProcentualnihUdela() {
		return udeoBel + udeoMasti + udeoSecera;
	}
	
	public String toString() {
		return super.toString() + "\nTezina: " + tezina + "\nEnergetska vrednost: " + izracunajEnerVred();
	}
	

}
