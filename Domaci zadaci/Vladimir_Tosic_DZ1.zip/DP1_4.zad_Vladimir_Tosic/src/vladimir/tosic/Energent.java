package vladimir.tosic;

public class Energent {
	
	double energetskaVrednost;
	
	Energent(){}
	
	Energent(double energetskaVrednost){
		energetskaVrednost = this.energetskaVrednost;
	}
	
	

}
