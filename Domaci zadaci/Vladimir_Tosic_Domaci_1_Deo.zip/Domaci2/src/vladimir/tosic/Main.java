package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static int faktor(int m) {
		if (m == 0)
			return 1;
		else {
			return m * faktor(m - 1);
		}
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Unesite broj");
		int b = sc.nextInt();

		if (b < 0) {
			System.out.println("Unesite pozitivan broj! ");
		} else {
			
			Broj fakt = (n) -> (faktor(n));

			if (b != 0) {
				System.out.println("Faktorijel zadatog broja je: " + fakt.faktorijel(b));
			} else {
				System.out.println("Faktorijel broja 0 je: " + fakt.faktorijel(b));
			}

		}
		sc.close();
	}

}
