package vladimir.tosic;

public interface Broj {
	
	// apstraktna metoda
	int faktorijel(int n);

}
