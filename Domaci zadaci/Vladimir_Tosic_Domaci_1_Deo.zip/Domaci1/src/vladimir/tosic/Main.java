package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite broj");
		int br = sc.nextInt();

		NegativanBroj ng = (broj) -> (broj < 0);
				
			if(ng.test(br))
				System.out.println("Broj " + br + " je negativan broj.");
			else 
				System.out.println("Broj " + br + " je pozitivan broj.");
			
			sc.close();
	}

}
