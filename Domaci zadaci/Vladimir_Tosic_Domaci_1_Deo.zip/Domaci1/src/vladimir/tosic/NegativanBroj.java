package vladimir.tosic;

public interface NegativanBroj {
	
	// apstraktna metoda
	boolean test(int broj);

}
