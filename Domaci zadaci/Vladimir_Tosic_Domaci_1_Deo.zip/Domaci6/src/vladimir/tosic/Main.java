package vladimir.tosic;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// 6. Napisati genericku klasu “OpisnaOcena” 
		// koja omogućuje smeštanje vrednosti (Ocena, OpisnaOcena). Ocena je celobrojna vrednost,
		// a OpisnaOcena je String-ovna vrednost. Ispis uraditi za ocene od 1 – 5.
		
		OpisnaOcena<Integer, String> obj = new OpisnaOcena<Integer, String>();
		
		Integer [] intNiz = {1, 2, 3, 4, 5};
		String [] stringNiz = {"Nedovoljan", "Dovoljan", "Dobar", "Vrlo dobar", "Odlican"};
		
		List<Integer> grade = new ArrayList<Integer>();
		List<String> Opisna = new ArrayList<String>();
		
		
		obj.setOcena(intNiz);
		obj.setOpisna(stringNiz);
		
		for(Integer i : intNiz) {
			grade.add(i);
		}
		for(String s : stringNiz) {
			Opisna.add(s);
		}
		
		for(int i = 0; i < grade.size(); i++) {
			System.out.println("Ocena: " + grade.get(i) + "\t Opisna: " + Opisna.get(i));
		}

	}

}
