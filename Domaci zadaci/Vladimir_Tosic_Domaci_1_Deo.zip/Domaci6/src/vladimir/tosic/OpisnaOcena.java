package vladimir.tosic;

public class OpisnaOcena <I, S> {
	
	I ocena [];
	S opisna [];
	
	OpisnaOcena() {
		
	}
	
	void setOcena(I [] ocena) {
		this.ocena = ocena;
	}
	void setOpisna(S opisna[]) {
		this.opisna = opisna;
	}
	public I[] getOcena() {
		return ocena;
	}
	public S[] getOpisna() {
		return opisna;
	}
	

}
