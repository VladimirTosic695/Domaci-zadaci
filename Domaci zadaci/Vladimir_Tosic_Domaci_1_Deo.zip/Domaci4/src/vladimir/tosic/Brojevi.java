package vladimir.tosic;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Brojevi {

	Scanner sc = new Scanner(System.in);

	List<Integer> kolekcija = new ArrayList<Integer>();

	void UnosBrojeva() {
		System.out.println("Za prekid unosa brojeva, unesite broj 0.");
		while (true) {
			System.out.println("Broj: ");
			int broj = sc.nextInt();

			if (broj == 0)
				break;
			this.kolekcija.add(broj);
		}
	}

	void ispisBrojeva() {
		System.out.println("Kolekcija sadrzi sledece brojeve: \n" + this.kolekcija + " ");
	}

}

