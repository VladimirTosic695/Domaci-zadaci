package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		// 4. Kreirati program za unos vrednosti sa konzole, smeštanje u kolkeciji 
		// ArrayList i ispisavanje smeštenih vrednosti.
		
		Brojevi ob = new Brojevi();
		
		ob.UnosBrojeva();
		ob.ispisBrojeva();
		
		
	}

}
