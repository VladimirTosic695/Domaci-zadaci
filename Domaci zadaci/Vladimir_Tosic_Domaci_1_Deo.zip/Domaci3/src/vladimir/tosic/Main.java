package vladimir.tosic;

public class Main {

	public static void main(String[] args) {
		// 3. Napisati Lambda izraz koji ispisuje nasumično izabran broj. 
		// Koristiti funkciju Math.random() za dobijanje nasumicnog broja.
		
		Nasumicno nasumicanBroj = () -> (Math.random());
		
		System.out.println("Nasumicno izabran broj: "+ nasumicanBroj.broj());

	}

}
