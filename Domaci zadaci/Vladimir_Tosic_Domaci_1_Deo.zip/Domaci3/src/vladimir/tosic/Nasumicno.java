package vladimir.tosic;

public interface Nasumicno {
	
	double broj();

}
