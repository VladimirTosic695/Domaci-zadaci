package vladimir.tosic;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Lista {
	
	Scanner sc = new Scanner(System.in);
	
	List<Integer> kolekcija = new LinkedList<Integer>();
	
	void unosBrojeva() {
		System.out.println("Za prekid unesite broj 0.");
		
		while (true) {
			System.out.println("Broj: ");
			int broj = sc.nextInt();
			if(broj == 0) {
				break;
			}
			this.kolekcija.add(broj);
		}
	}
	
	
}
