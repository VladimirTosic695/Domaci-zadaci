package vladimir.tosic;

import java.util.ListIterator;

public class Main {

	public static void main(String[] args) {
		// 5. Kreirati program za unos vrednosti sa konzole, 
		// smeštanje u kolekeciji LinkedList ispisavanje smeštenih vrednosti.
		
		Lista ob = new Lista();
		
		ob.unosBrojeva();
		
		ListIterator<Integer> iter = ob.kolekcija.listIterator();
		
		System.out.println("Kolekcija od prvog do poslednjeg elementa: ");
		while (iter.hasNext()) {
			System.out.print(iter.next() + " ");
		}
		
		System.out.println("\nKolekcija od poslednjeg do prvog elementa: ");
		while (iter.hasPrevious()) {
			System.out.print(iter.previous() + " ");
		}

	}

}
