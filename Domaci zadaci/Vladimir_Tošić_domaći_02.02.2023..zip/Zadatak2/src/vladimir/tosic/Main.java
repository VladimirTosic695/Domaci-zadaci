package vladimir.tosic;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 2. Napisati program koji iz zadatog niza briše duplikate. 1232145657 -> 1234567
		
		
		Scanner sc = new Scanner(System.in);
		
		List<Integer> brojevi = new ArrayList<Integer>();
		
		// Unos niza brojeva u listu
		System.out.println("Unesite niz od 10 brojeva.");
		for(int i = 0; i < 10; i++) {
			System.out.print("Broj: ");
			int broj = sc.nextInt();
				brojevi.add(broj);		
		}
		
		// Ispitivanje i izbacivanje duplikata iz liste 
		for(int i = 0; i < brojevi.size(); i++) {
			for(int j = i + 1; j < brojevi.size(); j++) {
				do {
				if(brojevi.get(i) == brojevi.get(j))
					brojevi.remove(j);
				} while(brojevi.get(i) == brojevi.get(j));
			}
		}
		
		// Stampanje liste 
		System.out.println("Lista brojeva: ");
		for(int niz : brojevi) {
			System.out.printf("%s " , niz);
		}
		
		sc.close();

	}

}
