package vladimir.tosic;

public class Zaposleni extends Osoba {
	
	private String firma, nazivOdeljenja;
	
	Zaposleni(){
		
	}
	Zaposleni(String ime,String datumRodjenja,String adresa,String firma,String odeljenje){
		super(ime, datumRodjenja, adresa);
		this.firma = firma;
		nazivOdeljenja = odeljenje;
	}
	
	public void setFirma(String firma) {
		this.firma = firma;
	}
	public void setNazivOdeljenja(String nazivOdeljanja) {
		this.nazivOdeljenja = nazivOdeljanja;
	}
	public String getFirma() {
		return firma;
	}
	public String getNazivOdeljenja() {
		return nazivOdeljenja;
	}
	
	public String PodaciZaposleni() {
		return super.PodaciOsoba() + "\nFirma: " + firma + "\nNaziv odeljenja: " + nazivOdeljenja;
	}

}
