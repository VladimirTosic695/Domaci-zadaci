package vladimir.tosic;

public class Osoba {
	
	protected String ime, datumRodjenja, adresa;
	
	Osoba(){
		
	}
	
	Osoba(String ime, String datumRodjenja, String adresa){
		this.ime = ime;
		this.datumRodjenja = datumRodjenja;
		this.adresa = adresa;
	}
	
	public void setIme(String ime) {
		this.ime = ime; 
	}
	public String getIme() {
		return ime;
	}
	public void setDatumRodjenja(String datumRodjenja) {
		this.datumRodjenja = datumRodjenja; 
	}
	public String getDatumRodjenja() {
		return datumRodjenja;
	}
	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}
	public String getAdresa() {
		return adresa;
	}
	
	public String PodaciOsoba() {
		return "Ime: " + ime + "\nDatum rodjenja: " + datumRodjenja + "\nAdresa: " + adresa;
	}
	
	
	

}
