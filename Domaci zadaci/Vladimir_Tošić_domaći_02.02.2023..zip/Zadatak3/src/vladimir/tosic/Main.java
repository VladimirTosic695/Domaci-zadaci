package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Osoba osoba = new Osoba();
		Djak djak = new Djak();
		Zaposleni radnik = new Zaposleni();
		
		System.out.println("Unos podataka o osobi.");
		
		System.out.println("Unesite ime osobe.");
		osoba.setIme(sc.nextLine());
		System.out.println("Unesite datum rodjenja osobe.");
		osoba.setDatumRodjenja(sc.nextLine());
		System.out.println("Unesite adresu osobe.");
		osoba.setAdresa(sc.nextLine());
		
		System.out.println(osoba.PodaciOsoba());
		System.out.println();
		
		System.out.println("Unos podataka o djaku.");
		
		System.out.println("Unesite ime djaka.");
		djak.setIme(sc.nextLine());
		System.out.println("Unesite datum rodjenja djaka.");
		djak.setDatumRodjenja(sc.nextLine());
		System.out.println("Unesite adresu djaka.");
		djak.setAdresa(sc.nextLine());
		System.out.println("Unesite naziv skole u koju djak ide.");
		djak.setNazivSkole(sc.nextLine());
		System.out.println("Unesite razred djaka.");
		djak.setRazred(sc.nextLine());
		
		System.out.println(djak.PodaciDjak());
		System.out.println();
		
		System.out.println("Unos podataka o zaposlenom.");
		
		System.out.println("Unesite ime zaposlenog.");
		radnik.setIme(sc.nextLine());
		System.out.println("Unesite datum rodjenja zaposlenog.");
		radnik.setDatumRodjenja(sc.nextLine());
		System.out.println("Unesite adresu zaposlenog.");
		radnik.setAdresa(sc.nextLine());
		System.out.println("Unesite naziv firme zaposlenog.");
		radnik.setFirma(sc.nextLine());
		System.out.println("Unesite sektor u kom je radnik zaposlen.");
		radnik.setNazivOdeljenja(sc.nextLine());
		
		System.out.println(radnik.PodaciZaposleni());
	
		sc.close();
	

	}

}
