package vladimir.tosic;

public class Djak extends Osoba {
	
	private String nazivSkole, razred;
	
	Djak(){
		
	}
	Djak(String ime, String datumRodjenja, String adresa, String nazivSkole, String razred){
		super(ime, datumRodjenja, adresa);
		this.nazivSkole = nazivSkole;
		this.razred = razred;
	}
	
	public void setNazivSkole(String nazivSkole) {
		this.nazivSkole = nazivSkole;
	}
	public String getNazivSkole() {
		return nazivSkole;
	}
	public void setRazred(String razred) {
		this.razred = razred;
	}
	public String getRazred() {
		return razred;
	}
	
	public String PodaciDjak() {
		return	super.PodaciOsoba() + "\nNaziv skole: " + nazivSkole + "\nRazred: " + razred;
	}

}
