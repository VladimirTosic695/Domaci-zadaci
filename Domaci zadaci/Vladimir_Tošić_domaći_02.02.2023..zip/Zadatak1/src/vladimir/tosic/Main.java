package vladimir.tosic;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception {
		// 1. Napisati program koji pretvara binarni u dekadni broj.

		Scanner sc = new Scanner(System.in);

		System.out.println("Unesite binarni broj. ");
		int broj = sc.nextInt();

		int binarno = broj;

		int suma = 0;
		int brojac = 0, p = 1;
		while (broj != 0) {
			try {
				int cifra = broj % 10;
				if (cifra != 1 && cifra != 0)
					throw new Exception();
				p = cifra * (int) Math.pow(2, brojac);
				brojac++;
				suma += p;
				broj = broj / 10;
				
			} catch (Exception e) {
				System.out.println("Uneti broj mora sadrzati samo cifre 1 i 0.");
				return;
			}
		} 
		System.out.println("Binarni broj: " + binarno + "\nDekadno: " + suma);
		sc.close();
	}

}
